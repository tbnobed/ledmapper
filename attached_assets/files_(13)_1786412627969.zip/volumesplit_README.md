# VolumeSplit

Splits image and video plates across the OBTV LED volume's three walls.

```
LEFT              CENTER                     RIGHT
2560 x 2048       6144 x 2560                2560 x 2048
10w x 8h cab      24w x 10h cab              10w x 8h cab
1x SX40           4x SX40                    1x SX40
\_________________ RTX PRO 4000 _______________/   sides.mov  5120 x 2048
                  RTX PRO 4500                     center.mov 6144 x 2560

unwrap 11264 x 2560   ·   400 cabinets @ 256 px
```

## Run it

```bash
docker compose up -d --build
```

Then open `http://<server>:8080`.

## What it does

Drop a plate (image or video), frame it in the browser, and the server renders
the wall feeds with ffmpeg. Previews are generated server-side, so the browser
never decodes a 4K plate — it just displays a JPEG of the current framing.

- **Center mode** fits the plate to the center wall (2.4:1) and extends the side
  walls outward by mirror-tiling a narrow edge sample. Best for 16:9 sources.
- **Canvas mode** spreads the plate across the full 4.4:1 unwrap. Use when the
  plate was outpainted to the right ratio.
- **Deck line** places the shorter side walls on a common floor (bottom) so the
  horizon runs continuously across the seams.
- **Sample width** controls how much of the center edge gets reflected. Narrow it
  until foreground subjects fall outside the sample, or they get cloned onto the
  side walls.

Output sets: `machine` (center + sides, one file per render node), `walls`
(three separate files), or `both`. Every job writes a `mapping.txt` recording
the exact settings used.

## Storage and throughput

Hap Q at 6144 x 2560 is roughly **2.1 MB/frame — 129 MB/s at 60p, 7.6 GB/min**.
Two things follow:

- `/data` needs real space. A 5-minute plate is around 38 GB for the center feed
  alone. Mount it on fast storage and prune finished jobs.
- Playback needs NVMe on each node. A SATA SSD or a network share will drop
  frames regardless of how clean the mapping is.

## Configuration

| Variable      | Default | Notes |
|---------------|---------|-------|
| `VS_DATA`     | `/data` | uploads, jobs, presets |
| `VS_WORKERS`  | `1`     | concurrent ffmpeg jobs — raise only with core headroom |

To pull plates straight off your media share instead of uploading through the
browser, bind-mount it over `/data/uploads` in `docker-compose.yml`.

## API

| Method | Path | Purpose |
|--------|------|---------|
| `POST` | `/api/sources` | upload a plate (multipart) |
| `GET`  | `/api/sources` | list plates |
| `POST` | `/api/preview` | one framing preview frame (JPEG) |
| `POST` | `/api/jobs` | queue a split |
| `GET`  | `/api/jobs/{id}` | status and progress |
| `GET`  | `/api/jobs/{id}/zip` | all outputs |
| `GET`  | `/healthz` | liveness |

The API takes the same parameters as the UI, so a render-farm script or a
watch-folder job can drive it without a browser.

## Known limits

- **Node sync is not solved here.** Center and sides decode on separate machines
  with separate playback clocks. Genlocking the SX40s keeps the panels locked but
  does not put the two machines on the same frame. Use whatever frame-sync Live FX
  exposes across nodes, or drive all six SX40 outputs from one machine.
- **Mirror fill repeats terrain.** Fine for ambient side light and centre-framed
  shots. If the camera pans across a seam, outpaint the plate first.
- No auth. Put it behind Authentik like the rest of the internal tools.
